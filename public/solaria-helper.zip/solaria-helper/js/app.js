const API = "https://worldofsolariammo.com";
const CLASS_ID = { Warrior: 0, Archer: 1, Hunter: 1, Mage: 2, Priest: 3, Defense: 4 };
const CLASS_COLOR = { Warrior: "#f07167", Archer: "#5ee0a0", Hunter: "#5ee0a0", Mage: "#6eb6ff", Priest: "#e8b86d", Defense: "#b9a0ff" };
const UNIVERSAL = new Set(["Shield", "Necklace", "Ring", "Bag"]);
const DOLL = [
  ["Necklace", "Necklace"], ["Helmet", "Helmet"], ["Shield", "Shield"],
  ["HandR", "Hand R"], ["Armor", "Armor"], ["HandL", "Hand L"],
  ["Weapon", "Weapon"], ["Legs", "Legs"], ["Belt", "Belt"],
  ["Ring", "Ring"], ["Boots", "Boots"], ["Ring2", "Ring"],
  ["Blank", ""], ["Bag", "Bag"], ["Blank", ""],
];
const RARITY = {
  pt: ["Comum", "Incomum", "Raro", "Épico", "Lendário", "Mítico"],
  en: ["Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic"],
  es: ["Común", "Poco común", "Raro", "Épico", "Legendario", "Mítico"],
};
const I18N = {
  pt: {
    app: "Solaria Helper", live: "AO VIVO", home: "Início", players: "Players", guilds: "Guildas",
    market: "Mercado", bosses: "Bosses", pvp: "PvP", items: "Itens", compare: "Comparar",
    favorites: "Favoritos", recent: "Vistos agora", search: "Buscar", searchPlayer: "Buscar player…",
    ranking: "Ranking", byLevel: "Por level", byGold: "Por gold", online: "Online", offline: "Offline",
    onlineOnly: "Só online", offers: "ofertas", activeBosses: "Bosses ativos", guildCount: "Guildas",
    equipment: "Equipment", levels: "Levels por classe", xpNext: "para o próximo level",
    recentPvp: "Combates recentes", win: "Vitória", loss: "Derrota", vs: "vs", by: "por",
    achievements: "Conquistas", members: "Membros", points: "Pontos", open: "Abrir", item: "Item",
    qty: "Qtd", gold: "Gold", seller: "Vendedor", server: "Servidor", allServers: "Todos servidores",
    unit: "Unitário", deal: "Oferta", rarity: "Raridade", allRarities: "Todas raridades",
    category: "Categoria", allCats: "Todas categorias", soldAt: "À venda agora", noOffers: "Nenhuma oferta",
    noData: "Sem dados", loading: "Carregando…", retry: "Tentar de novo",
    error: "Falha ao carregar. A API do jogo pode estar indisponível.",
    share: "Copiar link", copied: "Copiado", notifyBoss: "Alertas de boss", notifyOn: "Alertas ligados",
    map: "Mapa", compact: "Compacto", contrast: "Contraste", lang: "Idioma", official: "Site oficial",
    emptyFav: "Nenhum favorito — busque um player e toque na estrela.",
    compareA: "Player A", compareB: "Player B", kd: "K/D recente", created: "Criado", lastSeen: "Visto",
    honor: "Honor", guild: "Guilda", main: "main", saveItem: "Salvar item", saved: "Salvo",
    permadeath: "Permadeath", upcoming: "Próximos spawns", position: "Posição", activeFor: "Ativo há",
    footer: "Ferramenta da comunidade · dados públicos de worldofsolariammo.com",
    heroTitle: "Tudo do mundo, em um painel",
    heroDesc: "Ranking, mercado, bosses, guildas e ficha completa — ao vivo.",
    bargains: "Barganhas", nextBoss: "Próximo spawn", classMix: "Mix de classes (top 100)",
    goldLeaders: "Gold no top 100", leaders: "Placar", onlyDeals: "Só barganhas",
    onlyOnline: "Só online", allClasses: "Todas classes", loadMore: "Carregar mais",
    copyName: "Copiar nick", compareWith: "Comparar", score: "Power", notes: "Notas",
    notesPh: "Anotação só neste aparelho…", copyPos: "Copiar XY", eta: "Em",
    searchAll: "Buscar player, item, guilda…", more: "Mais", pages: "Páginas",
    noResults: "Nada encontrado.", cheaper: "mais barato", vsMedian: "vs mediana",
    favItems: "Itens salvos", emptyMarket: "Nenhuma oferta com esses filtros.",
    emptyBoss: "Nenhum boss ativo neste servidor.", emptyPvp: "Nenhum combate recente.",
    emptyItems: "Nenhum item encontrado.", emptyGuild: "Selecione uma guilda.",
    emptyCompare: "Digite dois nicks para comparar.", emptyDeals: "Nenhuma barganha agora.",
    winner: "vantagem", radar: "Radar de classes", feed: "Feed", topKillers: "Top killers",
    coords: "XY", ofTotal: "de", kind: "Tipo", allKinds: "Todos tipos",
    weapon: "Arma", armor: "Armadura", accessory: "Acessório", other: "Outro",
    onlyFavs: "Só favoritos", guildSearch: "Buscar guilda…", download: "Baixar ZIP",
  },
  en: {
    app: "Solaria Helper", live: "LIVE", home: "Home", players: "Players", guilds: "Guilds",
    market: "Market", bosses: "Bosses", pvp: "PvP", items: "Items", compare: "Compare",
    favorites: "Favorites", recent: "Recently viewed", search: "Search", searchPlayer: "Search player…",
    ranking: "Ranking", byLevel: "By level", byGold: "By gold", online: "Online", offline: "Offline",
    onlineOnly: "Online only", offers: "offers", activeBosses: "Active bosses", guildCount: "Guilds",
    equipment: "Equipment", levels: "Levels by class", xpNext: "to next level",
    recentPvp: "Recent fights", win: "Win", loss: "Loss", vs: "vs", by: "by",
    achievements: "Achievements", members: "Members", points: "Points", open: "Open", item: "Item",
    qty: "Qty", gold: "Gold", seller: "Seller", server: "Server", allServers: "All servers",
    unit: "Unit", deal: "Deal", rarity: "Rarity", allRarities: "All rarities",
    category: "Category", allCats: "All categories", soldAt: "For sale now", noOffers: "No offers",
    noData: "No data", loading: "Loading…", retry: "Retry",
    error: "Failed to load. The game API may be down.",
    share: "Copy link", copied: "Copied", notifyBoss: "Boss alerts", notifyOn: "Alerts on",
    map: "Map", compact: "Compact", contrast: "Contrast", lang: "Language", official: "Official site",
    emptyFav: "No favorites yet — search a player and tap the star.",
    compareA: "Player A", compareB: "Player B", kd: "Recent K/D", created: "Created", lastSeen: "Last seen",
    honor: "Honor", guild: "Guild", main: "main", saveItem: "Save item", saved: "Saved",
    permadeath: "Permadeath", upcoming: "Upcoming", position: "Position", activeFor: "Active for",
    footer: "Community tool · public data from worldofsolariammo.com",
    heroTitle: "The world, in one panel",
    heroDesc: "Rankings, market, bosses, guilds and full character sheets — live.",
    bargains: "Bargains", nextBoss: "Next spawn", classMix: "Class mix (top 100)",
    goldLeaders: "Gold in top 100", leaders: "Board", onlyDeals: "Deals only",
    onlyOnline: "Online only", allClasses: "All classes", loadMore: "Load more",
    copyName: "Copy name", compareWith: "Compare", score: "Power", notes: "Notes",
    notesPh: "Note stored on this device…", copyPos: "Copy XY", eta: "In",
    searchAll: "Search player, item, guild…", more: "More", pages: "Pages",
    noResults: "No results.", cheaper: "cheaper", vsMedian: "vs median",
    favItems: "Saved items", emptyMarket: "No offers for these filters.",
    emptyBoss: "No active bosses on this server.", emptyPvp: "No recent fights.",
    emptyItems: "No items found.", emptyGuild: "Pick a guild.",
    emptyCompare: "Type two names to compare.", emptyDeals: "No bargains right now.",
    winner: "lead", radar: "Class radar", feed: "Feed", topKillers: "Top killers",
    coords: "XY", ofTotal: "of", kind: "Type", allKinds: "All types",
    weapon: "Weapon", armor: "Armor", accessory: "Accessory", other: "Other",
    onlyFavs: "Favorites only", guildSearch: "Search guild…", download: "Download ZIP",
  },
  es: {
    app: "Solaria Helper", live: "EN VIVO", home: "Inicio", players: "Jugadores", guilds: "Gremios",
    market: "Mercado", bosses: "Jefes", pvp: "PvP", items: "Ítems", compare: "Comparar",
    favorites: "Favoritos", recent: "Vistos", search: "Buscar", searchPlayer: "Buscar jugador…",
    ranking: "Ranking", byLevel: "Por nivel", byGold: "Por oro", online: "En línea", offline: "Desconectado",
    onlineOnly: "Solo en línea", offers: "ofertas", activeBosses: "Jefes activos", guildCount: "Gremios",
    equipment: "Equipo", levels: "Niveles por clase", xpNext: "al siguiente nivel",
    recentPvp: "Combates recientes", win: "Victoria", loss: "Derrota", vs: "vs", by: "por",
    achievements: "Logros", members: "Miembros", points: "Puntos", open: "Abrir", item: "Ítem",
    qty: "Cant", gold: "Oro", seller: "Vendedor", server: "Servidor", allServers: "Todos los servidores",
    unit: "Unitario", deal: "Oferta", rarity: "Rareza", allRarities: "Todas las rarezas",
    category: "Categoría", allCats: "Todas las categorías", soldAt: "En venta ahora", noOffers: "Sin ofertas",
    noData: "Sin datos", loading: "Cargando…", retry: "Reintentar",
    error: "Error al cargar. La API del juego puede estar caída.",
    share: "Copiar enlace", copied: "Copiado", notifyBoss: "Alertas de jefe", notifyOn: "Alertas activas",
    map: "Mapa", compact: "Compacto", contrast: "Contraste", lang: "Idioma", official: "Sitio oficial",
    emptyFav: "Sin favoritos — busca un jugador y toca la estrella.",
    compareA: "Jugador A", compareB: "Jugador B", kd: "K/D reciente", created: "Creado", lastSeen: "Visto",
    honor: "Honor", guild: "Gremio", main: "main", saveItem: "Guardar ítem", saved: "Guardado",
    permadeath: "Permadeath", upcoming: "Próximos", position: "Posición", activeFor: "Activo hace",
    footer: "Herramienta de la comunidad · datos públicos de worldofsolariammo.com",
    heroTitle: "El mundo, en un panel",
    heroDesc: "Ranking, mercado, jefes, gremios y ficha completa — en vivo.",
    bargains: "Gangas", nextBoss: "Próximo spawn", classMix: "Mix de clases (top 100)",
    goldLeaders: "Oro en el top 100", leaders: "Marcador", onlyDeals: "Solo gangas",
    onlyOnline: "Solo en línea", allClasses: "Todas las clases", loadMore: "Cargar más",
    copyName: "Copiar nick", compareWith: "Comparar", score: "Power", notes: "Notas",
    notesPh: "Nota solo en este dispositivo…", copyPos: "Copiar XY", eta: "En",
    searchAll: "Buscar jugador, ítem, gremio…", more: "Más", pages: "Páginas",
    noResults: "Sin resultados.", cheaper: "más barato", vsMedian: "vs mediana",
    favItems: "Ítems guardados", emptyMarket: "Sin ofertas con esos filtros.",
    emptyBoss: "Ningún jefe activo en este servidor.", emptyPvp: "Sin combates recientes.",
    emptyItems: "Ningún ítem encontrado.", emptyGuild: "Elige un gremio.",
    emptyCompare: "Escribe dos nicks para comparar.", emptyDeals: "No hay gangas ahora.",
    winner: "ventaja", radar: "Radar de clases", feed: "Feed", topKillers: "Top killers",
    coords: "XY", ofTotal: "de", kind: "Tipo", allKinds: "Todos los tipos",
    weapon: "Arma", armor: "Armadura", accessory: "Accesorio", other: "Otro",
    onlyFavs: "Solo favoritos", guildSearch: "Buscar gremio…", download: "Descargar ZIP",
  },
};

const cache = new Map();
const PREF_KEY = "solaria-helper-prefs";
let prefs = loadPrefs();
let itemsIndex = null;
let itemsList = [];
let achievements = {};
let hoverTimer = 0;

function loadPrefs() {
  try {
    return {
      lang: "pt", compact: false, contrast: false, bossAlerts: false,
      favPlayers: [], favItems: [], favGuilds: [], recent: [], notes: {},
      ...JSON.parse(localStorage.getItem(PREF_KEY) || "{}"),
    };
  } catch { return { lang: "pt", favPlayers: [], favItems: [], favGuilds: [], recent: [], notes: {} }; }
}
function savePrefs() { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); }
function t(k) { return (I18N[prefs.lang] || I18N.pt)[k] || I18N.pt[k] || k; }
function $(sel, root = document) { return root.querySelector(sel); }
function el(html) { const d = document.createElement("div"); d.innerHTML = html.trim(); return d.firstElementChild; }
function esc(s) { return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&", "<": "<", ">": ">", '"': """, "'": "&#39;" }[c])); }
function fmtN(n) { return n == null ? "—" : Number(n).toLocaleString("pt-BR"); }
function fmtG(n) {
  if (n == null) return "—";
  if (n >= 1e9) return (n / 1e9).toFixed(1) + "B";
  if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
  if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
  return fmtN(n);
}
function timeAgo(s) {
  if (!s) return "—";
  const d = new Date(String(s).replace(" ", "T") + "Z");
  if (Number.isNaN(d.getTime())) return s;
  const sec = Math.floor((Date.now() - d.getTime()) / 1000);
  if (sec < 60) return sec + "s";
  if (sec < 3600) return Math.floor(sec / 60) + "m";
  if (sec < 86400) return Math.floor(sec / 3600) + "h";
  return Math.floor(sec / 86400) + "d";
}
function eta(ts, now) {
  if (!ts) return "—";
  const s = ts - Math.floor(now ?? Date.now() / 1000);
  if (s <= 0) return "now";
  if (s < 60) return s + "s";
  if (s < 3600) return Math.floor(s / 60) + "m";
  if (s < 86400) return Math.floor(s / 3600) + "h " + Math.floor((s % 3600) / 60) + "m";
  return Math.floor(s / 86400) + "d";
}
function elapsed(ts, now) {
  if (!ts) return "—";
  const s = Math.floor((now ?? Date.now() / 1000) - ts);
  if (s < 60) return s + "s";
  if (s < 3600) return Math.floor(s / 60) + "m";
  return Math.floor(s / 3600) + "h " + Math.floor((s % 3600) / 60) + "m";
}
function rarityName(r) { return (RARITY[prefs.lang] || RARITY.pt)[r ?? 0] || ("R" + r); }
function unitPrice(g, a) { return g && a ? g / a : null; }
function imgUrl(icon) {
  if (!icon) return null;
  if (icon.startsWith("http")) return icon;
  return API + "/" + icon.replace(/^\//, "");
}
function itemImg(icon, name, cls = "") {
  const src = imgUrl(icon) || (name ? API + "/item_images/" + encodeURIComponent(name) + ".png" : null);
  if (!src) return `<span class="ph">?</span>`;
  return `<img class="item-img pixel ${cls}" src="${esc(src)}" alt="${esc(name || "")}" loading="lazy" onerror="this.replaceWith(Object.assign(document.createElement('span'),{className:'ph',textContent:'?'}))">`;
}
async function getJson(path) {
  if (cache.has(path)) return cache.get(path);
  const p = fetch(API + "/" + path, { cache: "no-store" }).then(r => {
    if (!r.ok) throw new Error("HTTP " + r.status);
    return r.json();
  });
  cache.set(path, p);
  setTimeout(() => cache.delete(path), 45000);
  return p;
}
function buildIndex(raw) {
  const byId = new Map();
  const byName = new Map();
  const list = Object.entries(raw).map(([id, it]) => {
    const rec = { id, ...it };
    byId.set(id, rec);
    byId.set(id.toLowerCase(), rec);
    if (it.itemName) byName.set(it.itemName.toLowerCase(), rec);
    return rec;
  });
  return { byId, byName, list };
}
function findItem(key) {
  if (!itemsIndex || !key) return null;
  return itemsIndex.byId.get(key) || itemsIndex.byId.get(String(key).toLowerCase()) || itemsIndex.byName.get(String(key).toLowerCase()) || null;
}
function eqCat(eq) { return findItem(eq.item)?.eq?.cat || ""; }
function eqType(eq) { return findItem(eq.item)?.eq?.type || 0; }
function filterClassEquip(equipment, className) {
  const c = CLASS_ID[className] ?? 0;
  const base = c === 0 ? 0 : 12 + (c - 1) * 8;
  return (equipment || []).filter(e => UNIVERSAL.has(eqCat(e)) || (e.slot >= base && e.slot <= base + 7));
}
function paperDoll(items) {
  const byCat = {};
  const rings = [];
  let weapon;
  for (const e of items) {
    const cat = eqCat(e);
    if (cat === "Ring") rings.push(e);
    else if (eqType(e) === 1) { if (!weapon) weapon = e; }
    else if (cat) byCat[cat] = e;
  }
  return {
    Necklace: byCat.Necklace, Helmet: byCat.Head, Shield: byCat.Shield,
    HandR: byCat.Hand, Armor: byCat.Chest, HandL: byCat.Hand2, Weapon: weapon,
    Legs: byCat.Legs, Belt: byCat.Belt, Ring: rings[0], Boots: byCat.Foot,
    Ring2: rings[1], Bag: byCat.Bag,
  };
}
function equipScore(items) {
  return items.reduce((s, e) => s + (e.level || 0) + (e.rank || 0) * 10 + (e.rarety || e.rarity || 0) * 25, 0);
}
function medianMap(offers) {
  const map = new Map();
  for (const o of offers) {
    const u = unitPrice(o.gold, o.amount);
    if (u == null || !o.item) continue;
    const arr = map.get(o.item) || [];
    arr.push(u); map.set(o.item, arr);
  }
  const med = new Map();
  for (const [k, arr] of map) {
    arr.sort((a, b) => a - b);
    med.set(k, arr[Math.floor(arr.length / 2)] || 0);
  }
  return med;
}
function isDeal(o, med) {
  const u = unitPrice(o.gold, o.amount);
  const m = o.item ? med.get(o.item) : null;
  return u != null && m > 0 && u < m * 0.7;
}
function hashRoute() {
  const h = location.hash.replace(/^#/, "") || "/";
  const [path, qs] = h.split("?");
  const q = Object.fromEntries(new URLSearchParams(qs || ""));
  return { path: path || "/", q };
}
function go(path, q = {}) {
  const qs = new URLSearchParams(q).toString();
  location.hash = path + (qs ? "?" + qs : "");
}
function isFavP(n) { return prefs.favPlayers.some(x => x.toLowerCase() === String(n).toLowerCase()); }
function toggleFavP(n) {
  const i = prefs.favPlayers.findIndex(x => x.toLowerCase() === n.toLowerCase());
  if (i >= 0) prefs.favPlayers.splice(i, 1); else prefs.favPlayers.unshift(n);
  prefs.favPlayers = prefs.favPlayers.slice(0, 40);
  savePrefs();
}
function isFavI(id) { return prefs.favItems.includes(id); }
function toggleFavI(id) {
  if (isFavI(id)) prefs.favItems = prefs.favItems.filter(x => x !== id);
  else prefs.favItems = [id, ...prefs.favItems].slice(0, 80);
  savePrefs();
}
function touchRecent(n) {
  prefs.recent = [n, ...prefs.recent.filter(x => x.toLowerCase() !== n.toLowerCase())].slice(0, 12);
  savePrefs();
}
function copy(text) {
  navigator.clipboard.writeText(text).then(() => toast(t("copied"))).catch(() => toast(text));
}
function toast(msg) {
  let n = $(".toast");
  if (!n) { n = el(`<div id="toast" style="position:fixed;bottom:72px;left:50%;transform:translateX(-50%);background:var(--surface-2);border:1px solid var(--line);padding:8px 14px;border-radius:8px;z-index:80;font-size:13px"></div>`); document.body.appendChild(n); }
  n.textContent = msg; n.classList.remove("hidden");
  clearTimeout(n._t); n._t = setTimeout(() => n.classList.add("hidden"), 1800);
}
function playerLink(name) { return `<a href="#/players?name=${encodeURIComponent(name)}">${esc(name)}</a>`; }
function itemHot(id, inner, cls = "") {
  return `<button type="button" class="item-hot ${cls}" data-item="${esc(id || "")}" style="background:none;border:0;padding:0;text-align:left">${inner}</button>`;
}

async function ensureItems() {
  if (itemsIndex) return itemsIndex;
  const raw = await getJson("items.json");
  itemsIndex = buildIndex(raw);
  itemsList = itemsIndex.list;
  return itemsIndex;
}

function applyChrome() {
  document.documentElement.lang = prefs.lang;
  document.documentElement.dataset.compact = String(!!prefs.compact);
  document.documentElement.dataset.contrast = String(!!prefs.contrast);
  $("#langSel").value = prefs.lang;
  $("#compactChk").checked = !!prefs.compact;
  $("#contrastChk").checked = !!prefs.contrast;
  $("#bossBtn").textContent = prefs.bossAlerts ? t("notifyOn") : t("notifyBoss");
  document.querySelectorAll("[data-i18n]").forEach(n => { n.textContent = t(n.dataset.i18n); });
  const { path } = hashRoute();
  document.querySelectorAll(".nav a, .bottom-nav a").forEach(a => {
    const to = a.getAttribute("href").replace("#", "");
    a.classList.toggle("active", to === "/" ? path === "/" : path.startsWith(to));
  });
  const titles = { "/": "home", "/players": "players", "/guilds": "guilds", "/market": "market", "/bosses": "bosses", "/pvp": "pvp", "/items": "items", "/compare": "compare" };
  $("#pageTitle").textContent = t(titles[path] || "home");
}

async function render() {
  applyChrome();
  const root = $("#view");
  root.innerHTML = `<p class="muted">${t("loading")}</p>`;
  try {
    const { path, q } = hashRoute();
    if (path === "/players") await viewPlayers(root, q);
    else if (path === "/guilds") await viewGuilds(root, q);
    else if (path === "/market") await viewMarket(root, q);
    else if (path === "/bosses") await viewBosses(root, q);
    else if (path === "/pvp") await viewPvp(root, q);
    else if (path === "/items") await viewItems(root, q);
    else if (path === "/compare") await viewCompare(root, q);
    else await viewHome(root);
  } catch (e) {
    root.innerHTML = `<div class="err">${t("error")}<br><button class="btn" id="retry">${t("retry")}</button></div>`;
    $("#retry")?.addEventListener("click", render);
  }
}

function mixBars(players) {
  const mix = {};
  for (const p of players) mix[p.class || "?"] = (mix[p.class || "?"] || 0) + 1;
  const max = Math.max(...Object.values(mix), 1);
  return Object.entries(mix).sort((a, b) => b[1] - a[1]).map(([k, v]) =>
    `<div class="bar-row"><span style="width:72px">${esc(k)}</span><i style="width:${(v / max) * 70}%;background:${CLASS_COLOR[k] || "var(--teal)"}"></i><span class="tabular">${v}</span></div>`
  ).join("");
}

async function viewHome(root) {
  const [board, market, bosses, guilds, pvp] = await Promise.all([
    getJson("players.php?board=overall&realm=normal"),
    getJson("tienda.php"),
    getJson("bosses.php"),
    getJson("guild.php?realm=normal"),
    getJson("players.php?pvp=1"),
  ]);
  await ensureItems().catch(() => {});
  const players = board.players || [];
  const online = players.filter(p => p.online).length;
  const bossCount = (bosses.servers || []).reduce((a, s) => a + (s.count || 0), 0);
  const med = medianMap(market.offers || []);
  const deals = (market.offers || []).filter(o => isDeal(o, med)).slice(0, 8);
  const upcoming = (bosses.servers || []).flatMap(s => (s.upcoming || []).map(u => ({ ...u, server: s.server }))).sort((a, b) => (a.eta || 0) - (b.eta || 0)).slice(0, 6);
  const goldTop = [...players].sort((a, b) => (b.gold || 0) - (a.gold || 0)).slice(0, 8);
  root.innerHTML = `
    <div style="margin-bottom:16px">
      <h2 style="font-family:var(--display);font-size:28px;margin:0">${t("heroTitle")}</h2>
      <p class="muted">${t("heroDesc")}</p>
    </div>
    <div class="grid-4" style="margin-bottom:16px">
      <div class="stat"><b>${online}+</b><span>${t("online")} (top 100)</span></div>
      <div class="stat"><b>${fmtN(market.count)}</b><span>${t("offers")}</span></div>
      <div class="stat"><b>${bossCount}</b><span>${t("activeBosses")}</span></div>
      <div class="stat"><b>${fmtN(guilds.count)}</b><span>${t("guildCount")}</span></div>
    </div>
    <div class="card" style="margin-bottom:16px"><div class="pad">
      <strong>${t("favorites")}</strong>
      <div class="row" style="margin-top:8px">${prefs.favPlayers.length ? prefs.favPlayers.map(n => `<a class="chip" href="#/players?name=${encodeURIComponent(n)}">${esc(n)}</a>`).join("") : `<span class="muted">${t("emptyFav")}</span>`}</div>
      ${prefs.recent.length ? `<div class="muted" style="margin-top:10px">${t("recent")}</div><div class="row" style="margin-top:6px">${prefs.recent.map(n => `<a class="chip" href="#/players?name=${encodeURIComponent(n)}">${esc(n)}</a>`).join("")}</div>` : ""}
    </div></div>
    <div class="grid-2">
      <div class="card"><h3>${t("bargains")}</h3>${deals.length ? `<table>${deals.map(o => {
        const rec = findItem(o.item); const u = unitPrice(o.gold, o.amount); const m = med.get(o.item);
        const pct = u && m ? Math.round((1 - u / m) * 100) : 0;
        return `<tr><td>${itemHot(rec?.id || o.item, itemImg(rec?.icon, o.item) + " <b>" + esc(o.item) + "</b>")}</td><td class="gold">${fmtG(o.gold)}</td><td class="ok">-${pct}%</td></tr>`;
      }).join("")}</table>` : `<div class="empty">${t("emptyDeals")}</div>`}</div>
      <div class="card"><h3>${t("upcoming")}</h3>${upcoming.length ? `<table>${upcoming.map(u => `<tr><td>${esc(u.name || "")}</td><td>${esc(u.server)}</td><td class="teal tabular">${t("eta")} ${eta(u.eta, bosses.now)}</td></tr>`).join("")}</table>` : `<div class="empty">${t("noData")}</div>`}</div>
    </div>
    <div class="grid-2" style="margin-top:16px">
      <div class="card"><h3>${t("classMix")}</h3><div class="pad">${mixBars(players)}</div></div>
      <div class="card"><h3>${t("goldLeaders")}</h3><table>${goldTop.map((p, i) => `<tr><td class="mist">${i + 1}</td><td>${playerLink(p.name)}</td><td class="gold">${fmtG(p.gold)}</td></tr>`).join("")}</table></div>
    </div>
    <div class="grid-2" style="margin-top:16px">
      <div class="card"><h3>${t("recentPvp")}</h3><table>${(pvp.kills || []).slice(0, 8).map(k => `<tr><td class="ok">${playerLink(k.killer)}</td><td class="danger">${playerLink(k.victim)}</td><td class="mist">${esc(k.server || "")} ${timeAgo(k.time)}</td></tr>`).join("")}</table></div>
      <div class="card"><h3>${t("ranking")}</h3><table>${players.slice(0, 10).map((p, i) => `<tr><td class="mist">${i + 1}</td><td>${playerLink(p.name)} <span class="mist">${esc(p.class || "")}</span></td><td>${p.level}</td><td class="gold">${fmtG(p.gold)}</td></tr>`).join("")}</table></div>
    </div>`;
  bindItemHots(root);
}

function profileHtml(p) {
  const cls = p.class || p.classes?.[0]?.name || "Warrior";
  const filtered = filterClassEquip(p.equipment, cls);
  const doll = paperDoll(filtered);
  const score = equipScore(filtered);
  const kills = p.kills || [];
  const wins = kills.filter(k => k.killer?.toLowerCase() === p.name.toLowerCase()).length;
  const losses = kills.length - wins;
  const grade = p.vip ? "g3" : ("g" + Math.min(3, Math.max(0, p.grade || 0)));
  const dollHtml = DOLL.map(([key, label]) => {
    if (key === "Blank") return `<div></div>`;
    const e = doll[key];
    if (!e) return `<div class="eq-slot" style="opacity:.5"><small>${label}</small><span class="mist">—</span></div>`;
    const rec = findItem(e.item);
    const rar = (e.rarety && e.rarety > 0 ? e.rarety : rec?.rarity) || 0;
    return `<div class="eq-slot item-hot" data-item="${esc(rec?.id || e.item)}"><small>${label}</small>${itemImg(rec?.icon || ("item_images/" + e.item + ".png"), rec?.itemName || e.item)}<div class="trunc"><b>${esc(rec?.itemName || e.item)}</b></div><small class="r${rar}">${rarityName(rar)} ${e.level ? "Lv " + e.level : ""} ${e.rank ? "+" + e.rank : ""}</small></div>`;
  }).join("");
  const classTabs = (p.classes || []).map(c => `<button class="btn class-tab ${c.name === cls ? "primary" : ""}" data-cls="${esc(c.name)}">${esc(c.name)} Lv ${c.level}</button>`).join("");
  const xp = (p.classes || []).map(c => {
    const pct = Math.max(0, Math.min(100, c.pct || 0));
    return `<div class="card" style="padding:12px;margin-bottom:8px;border-color:${c.name === p.class ? "color-mix(in srgb, var(--teal) 40%, var(--line))" : "var(--line)"}">
      <div class="row" style="justify-content:space-between"><b>${esc(c.name)} ${c.name === p.class ? `<span class="teal" style="font-size:10px">${t("main")}</span>` : ""}</b><span style="font-family:var(--display);font-size:22px;color:${CLASS_COLOR[c.name] || "var(--fog)"}">${c.level}</span></div>
      <div class="xp" style="margin-top:8px"><i style="width:${pct}%;background:${CLASS_COLOR[c.name] || "var(--teal)"}"></i></div>
      <div class="muted">${pct}% ${t("xpNext")}</div></div>`;
  }).join("");
  const ach = (p.achievements || []).slice(0, 12).map(a => {
    const m = achievements[String(a.id)] || {};
    const mx = Math.max(m.maxLevel || 0, m.maxLevel2 || 0) || 24;
    const pct = Math.min(100, (a.level / mx) * 100);
    return `<div style="margin:8px 0"><div class="row" style="justify-content:space-between"><span>${esc(m.name || "#" + a.id)}</span><span class="mist">Lv ${a.level}${mx ? " / " + mx : ""}</span></div><div class="xp"><i style="width:${pct}%;background:var(--gold)"></i></div></div>`;
  }).join("");
  return `<section class="card" data-profile="${esc(p.name)}" data-cls="${esc(cls)}">
    <div class="pad" style="border-bottom:1px solid var(--line);background:var(--ink-2);border-radius:12px 12px 0 0">
      <div class="row" style="justify-content:space-between">
        <div>
          <h2 class="${grade}" style="font-family:var(--display);margin:0">${esc(p.name)}
            <button class="btn icon fav-p" data-name="${esc(p.name)}">${isFavP(p.name) ? "★" : "☆"}</button>
          </h2>
          <p class="muted">Level ${p.level ?? "—"} · ${esc(p.class || "")} ${p.guild ? "· <a href='#/guilds?name=" + encodeURIComponent(p.guild) + "'>" + esc(p.guild) + "</a>" : ""} · ${p.online ? `<span class="ok">● ${t("online")}${p.server ? " · " + esc(p.server) : ""}</span>` : t("offline")}</p>
        </div>
        <div class="row">
          <span class="chip gold">${fmtG(p.gold)}</span>
          <span class="chip">${fmtN(p.honor)} ${t("honor")}</span>
          <span class="chip">${t("kd")}: ${wins}/${losses}</span>
          <span class="chip">${t("score")}: ${fmtN(score)}</span>
        </div>
      </div>
      <div class="row" style="margin-top:8px">
        <button class="btn copy-name" data-name="${esc(p.name)}">${t("copyName")}</button>
        <a class="btn" href="#/compare?a=${encodeURIComponent(p.name)}">${t("compareWith")}</a>
        <button class="btn share-p" data-name="${esc(p.name)}">${t("share")}</button>
      </div>
      <label class="muted" style="display:block;margin-top:10px">${t("notes")}</label>
      <textarea class="note-box" data-name="${esc(p.name)}" placeholder="${t("notesPh")}">${esc(prefs.notes[p.name] || "")}</textarea>
    </div>
    <div class="grid-2">
      <div class="pad">
        <div class="muted" style="margin-bottom:8px">${t("equipment")} (${esc(cls)})</div>
        <div class="row" style="margin-bottom:8px">${classTabs}</div>
        <div class="eq-grid">${dollHtml}</div>
      </div>
      <div class="pad">
        <div class="muted" style="margin-bottom:8px">${t("levels")}</div>
        ${xp}
        ${kills.length ? `<div class="muted" style="margin:12px 0 6px">${t("recentPvp")}</div>` + kills.slice(0, 8).map(k => {
          const won = k.killer?.toLowerCase() === p.name.toLowerCase();
          const other = won ? k.victim : k.killer;
          return `<div class="chip" style="display:block;margin:4px 0"><span class="${won ? "ok" : "danger"}">${won ? t("win") : t("loss")}</span> ${won ? t("vs") : t("by")} ${playerLink(other)} <span class="mist">${esc(k.server || "")} ${timeAgo(k.time)}</span></div>`;
        }).join("") : ""}
        ${ach ? `<div class="muted" style="margin:12px 0 6px">${t("achievements")} ${p.achPoints != null ? "· " + p.achPoints + " pts" : ""}</div>${ach}` : ""}
      </div>
    </div>
  </section>`;
}

function bindProfile(root, p) {
  root.querySelectorAll(".class-tab").forEach(btn => btn.addEventListener("click", () => {
    const next = { ...p, class: btn.dataset.cls };
    const wrap = root.querySelector("[data-profile]");
    wrap.outerHTML = profileHtml(next);
    bindProfile(root, next);
    bindItemHots(root);
  }));
  root.querySelector(".fav-p")?.addEventListener("click", (e) => { toggleFavP(p.name); e.currentTarget.textContent = isFavP(p.name) ? "★" : "☆"; });
  root.querySelector(".copy-name")?.addEventListener("click", () => copy(p.name));
  root.querySelector(".share-p")?.addEventListener("click", () => copy(location.href));
  root.querySelector(".note-box")?.addEventListener("change", (e) => { prefs.notes[p.name] = e.target.value; savePrefs(); });
}

async function viewPlayers(root, q) {
  await ensureItems().catch(() => {});
  achievements = await getJson("achievements.json").catch(() => ({}));
  const board = q.board === "gold" ? "gold" : "overall";
  const data = await getJson(`players.php?board=${board}&realm=normal`);
  let list = data.players || [];
  const servers = [...new Set(list.map(p => p.server).filter(Boolean))];
  const classes = [...new Set(list.map(p => p.class).filter(Boolean))];
  if (q.server) list = list.filter(p => p.server === q.server);
  if (q.cls) list = list.filter(p => p.class === q.cls);
  if (q.online) list = list.filter(p => p.online);
  const names = list.map(p => p.name);
  let profile = "";
  if (q.name) {
    const p = await getJson("players.php?name=" + encodeURIComponent(q.name));
    if (p?.name) { touchRecent(p.name); profile = profileHtml(p); }
    else profile = `<div class="err">${t("noData")}</div>`;
  }
  root.innerHTML = `
    <form class="row" id="pform">
      <input name="name" list="plist" value="${esc(q.name || "")}" placeholder="${t("searchPlayer")}" style="flex:1;min-width:180px">
      <datalist id="plist">${names.slice(0, 100).map(n => `<option value="${esc(n)}">`).join("")}</datalist>
      <button class="btn primary">${t("search")}</button>
      <select name="board"><option value="overall">${t("byLevel")}</option><option value="gold" ${board === "gold" ? "selected" : ""}>${t("byGold")}</option></select>
      <select name="server"><option value="">${t("allServers")}</option>${servers.map(s => `<option ${q.server === s ? "selected" : ""}>${esc(s)}</option>`).join("")}</select>
      <select name="cls"><option value="">${t("allClasses")}</option>${classes.map(c => `<option ${q.cls === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
      <label class="chip"><input type="checkbox" name="online" ${q.online ? "checked" : ""}> ${t("onlineOnly")}</label>
    </form>
    <div id="profile" style="margin:16px 0">${profile}</div>
    <div class="card" style="overflow:auto"><table>
      <thead class="sticky-head"><tr><th>#</th><th>${t("players")}</th><th>Lv</th><th>${t("gold")}</th><th>${t("guild")}</th><th>${t("server")}</th></tr></thead>
      <tbody>${list.slice(0, 100).map((p, i) => `<tr>
        <td class="mist">${i + 1}</td>
        <td>${playerLink(p.name)} <span class="mist">${esc(p.class || "")}</span> ${p.online ? '<span class="ok">●</span>' : ""} ${isFavP(p.name) ? '<span class="fav">★</span>' : ""}</td>
        <td class="tabular">${p.level ?? "—"}</td>
        <td class="gold">${fmtG(p.gold)}</td>
        <td>${p.guild ? `<a href="#/guilds?name=${encodeURIComponent(p.guild)}">${esc(p.guild)}</a>` : "—"}</td>
        <td class="mist">${esc(p.server || "—")}</td>
      </tr>`).join("")}</tbody>
    </table></div>`;
  $("#pform").addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    go("/players", {
      name: fd.get("name") || undefined,
      board: fd.get("board") || undefined,
      server: fd.get("server") || undefined,
      cls: fd.get("cls") || undefined,
      online: fd.get("online") ? "1" : undefined,
    });
  });
  if (q.name && profile.includes("data-profile")) {
    const p = await getJson("players.php?name=" + encodeURIComponent(q.name));
    bindProfile(root, p);
    bindItemHots(root);
  }
}

async function viewGuilds(root, q) {
  const data = await getJson("guild.php?realm=normal");
  const board = await getJson("players.php?board=overall&realm=normal").catch(() => ({ players: [] }));
  const byName = new Map((board.players || []).map(p => [p.name.toLowerCase(), p]));
  let guilds = data.guilds || [];
  const gq = (q.q || "").toLowerCase();
  if (gq) guilds = guilds.filter(g => g.name.toLowerCase().includes(gq));
  let detail = "";
  if (q.name) {
    const d = await getJson("guild.php?members=" + encodeURIComponent(q.name));
    const members = d.members || [];
    const online = members.filter(m => m.online).length;
    const mixPlayers = members.map(m => byName.get(m.name.toLowerCase())).filter(Boolean);
    detail = `<section class="card" style="margin-top:16px">
      <div class="pad" style="background:var(--ink-2);border-bottom:1px solid var(--line)">
        <h2 style="font-family:var(--display);margin:0">${esc(q.name)}</h2>
        <div class="row" style="margin-top:8px">
          <span class="chip">${t("points")}: ${fmtN(guilds.find(g => g.name === q.name)?.points)}</span>
          <span class="chip">${t("members")}: ${fmtN(d.count || members.length)}</span>
          <span class="chip ok">● ${t("online")}: ${online}</span>
          <button class="btn share-g">${t("share")}</button>
        </div>
      </div>
      ${mixPlayers.length ? `<div class="pad">${mixBars(mixPlayers)}</div>` : ""}
      <table>${members.map((m, i) => {
        const p = byName.get(m.name.toLowerCase());
        return `<tr><td class="mist">${i + 1}</td><td>${playerLink(m.name)}</td><td>${m.level ?? "—"}</td><td>${esc(m.rank || "—")}</td><td>${esc(p?.class || "—")}</td><td>${m.online ? `<span class="ok">${t("online")}</span>` : t("offline")}</td><td class="mist">${m.lastSeen ? timeAgo(m.lastSeen) : "—"}</td></tr>`;
      }).join("")}</table>
    </section>`;
  }
  root.innerHTML = `
    <form class="row" id="gform"><input name="q" value="${esc(q.q || "")}" placeholder="${t("guildSearch")}" style="flex:1"><button class="btn primary">${t("search")}</button></form>
    <div class="card" style="margin-top:12px;overflow:auto"><table>
      <thead class="sticky-head"><tr><th>#</th><th>${t("guilds")}</th><th>${t("points")}</th><th>${t("members")}</th><th></th></tr></thead>
      <tbody>${guilds.map((g, i) => `<tr>
        <td class="mist">${i + 1}</td><td><b>${esc(g.name)}</b></td><td class="tabular">${fmtN(g.points)}</td><td>${fmtN(g.members)}</td>
        <td><a class="btn" href="#/guilds?name=${encodeURIComponent(g.name)}">${t("open")}</a></td>
      </tr>`).join("")}</tbody>
    </table></div>${detail || `<p class="muted">${t("emptyGuild")}</p>`}`;
  $("#gform").addEventListener("submit", (e) => { e.preventDefault(); go("/guilds", { q: new FormData(e.target).get("q") || undefined, name: q.name }); });
  root.querySelector(".share-g")?.addEventListener("click", () => copy(location.href));
}

async function viewMarket(root, q) {
  await ensureItems().catch(() => {});
  const data = await getJson("tienda.php");
  const offers = data.offers || [];
  const med = medianMap(offers);
  const servers = [...new Set(offers.map(o => o.server).filter(Boolean))];
  const cats = [...new Set(itemsList.map(i => i.eq?.cat).filter(Boolean))].sort();
  let list = offers.filter(o => {
    const rec = findItem(o.item);
    if (q.q) {
      const n = q.q.toLowerCase();
      if (!(o.item || "").toLowerCase().includes(n) && !(o.player || "").toLowerCase().includes(n)) return false;
    }
    if (q.server && o.server !== q.server) return false;
    if (q.rarity != null && q.rarity !== "" && String(o.rarety ?? rec?.rarity ?? 0) !== q.rarity) return false;
    if (q.cat && rec?.eq?.cat !== q.cat) return false;
    if (q.deals && !isDeal(o, med)) return false;
    return true;
  });
  if (q.sort === "gold-asc") list = [...list].sort((a, b) => (a.gold || 0) - (b.gold || 0));
  if (q.sort === "gold-desc") list = [...list].sort((a, b) => (b.gold || 0) - (a.gold || 0));
  if (q.sort === "unit") list = [...list].sort((a, b) => (unitPrice(a.gold, a.amount) ?? 1e18) - (unitPrice(b.gold, b.amount) ?? 1e18));
  if (q.sort === "qty") list = [...list].sort((a, b) => (b.amount || 0) - (a.amount || 0));
  root.innerHTML = `
    <form class="row" id="mform">
      <input name="q" value="${esc(q.q || "")}" placeholder="${t("item")} / ${t("seller")}" style="flex:1;min-width:140px">
      <select name="server"><option value="">${t("allServers")}</option>${servers.map(s => `<option ${q.server === s ? "selected" : ""}>${esc(s)}</option>`).join("")}</select>
      <select name="rarity"><option value="">${t("allRarities")}</option>${[0,1,2,3,4,5].map(r => `<option value="${r}" ${q.rarity === String(r) ? "selected" : ""}>${rarityName(r)}</option>`).join("")}</select>
      <select name="cat"><option value="">${t("allCats")}</option>${cats.map(c => `<option ${q.cat === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
      <select name="sort">
        <option value="">${t("sortDefault") || "Padrão"}</option>
        <option value="unit" ${q.sort === "unit" ? "selected" : ""}>Unitário</option>
        <option value="gold-asc" ${q.sort === "gold-asc" ? "selected" : ""}>Gold ↑</option>
        <option value="gold-desc" ${q.sort === "gold-desc" ? "selected" : ""}>Gold ↓</option>
      </select>
      <label class="chip"><input type="checkbox" name="deals" ${q.deals ? "checked" : ""}> ${t("onlyDeals")}</label>
      <button class="btn primary">${t("search")}</button>
      <span class="muted">${list.length} ${t("offers")}</span>
    </form>
    <div class="card" style="margin-top:12px;overflow:auto">${list.length ? `<table>
      <thead class="sticky-head"><tr><th></th><th>${t("item")}</th><th>${t("qty")}</th><th>${t("gold")}</th><th>${t("unit")}</th><th>${t("seller")}</th><th>${t("server")}</th></tr></thead>
      <tbody>${list.slice(0, 250).map(o => {
        const rec = findItem(o.item); const u = unitPrice(o.gold, o.amount); const deal = isDeal(o, med);
        const m = o.item ? med.get(o.item) : null; const pct = u && m ? Math.round((1 - u / m) * 100) : 0;
        return `<tr>
          <td>${itemHot(rec?.id || o.item, itemImg(rec?.icon, o.item))}</td>
          <td>${itemHot(rec?.id || o.item, `<b>${esc(o.item)}</b>`)}${deal ? `<span class="deal">${t("deal")} -${pct}%</span>` : ""}</td>
          <td class="tabular">${fmtN(o.amount)}</td>
          <td class="gold">${fmtG(o.gold)}</td>
          <td class="mist">${u != null ? fmtG(u) : "—"}</td>
          <td>${o.player ? playerLink(o.player) : "—"}${o.online ? ' <span class="ok">●</span>' : ""}</td>
          <td class="mist">${esc(o.server || "")}</td>
        </tr>`;
      }).join("")}</tbody></table>` : `<div class="empty">${t("emptyMarket")}</div>`}</div>`;
  $("#mform").addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    go("/market", {
      q: fd.get("q") || undefined, server: fd.get("server") || undefined,
      rarity: fd.get("rarity") || undefined, cat: fd.get("cat") || undefined,
      sort: fd.get("sort") || undefined, deals: fd.get("deals") ? "1" : undefined,
    });
  });
  bindItemHots(root);
}

async function viewBosses(root, q) {
  const data = await getJson("bosses.php");
  const servers = data.servers || [];
  const shown = q.server ? servers.filter(s => s.server === q.server) : servers;
  const all = shown.flatMap(s => (s.bosses || []).map(b => ({ ...b, server: s.server })));
  const xs = all.map(b => b.x || 0), ys = all.map(b => b.y || 0);
  const minX = Math.min(...xs, 0), maxX = Math.max(...xs, 1), minY = Math.min(...ys, 0), maxY = Math.max(...ys, 1);
  const dots = all.map(b => {
    const x = ((b.x || 0) - minX) / (maxX - minX || 1) * 360 + 20;
    const y = 200 - ((b.y || 0) - minY) / (maxY - minY || 1) * 180;
    return `<g><circle cx="${x}" cy="${y}" r="5" fill="var(--teal)"/><text x="${x + 8}" y="${y + 4}" fill="var(--fog)" font-size="9">${esc(b.server)} ${esc(b.name)}</text></g>`;
  }).join("");
  const upcoming = shown.flatMap(s => (s.upcoming || []).map(u => ({ ...u, server: s.server }))).sort((a, b) => (a.eta || 0) - (b.eta || 0));
  if (prefs.bossAlerts && "Notification" in window && Notification.permission === "granted") {
    /* already requested from chrome */
  }
  root.innerHTML = `
    <div class="row"><select id="bserver"><option value="">${t("allServers")}</option>${servers.map(s => `<option ${q.server === s.server ? "selected" : ""}>${esc(s.server)}</option>`).join("")}</select></div>
    ${all.length ? `<div class="card" style="margin-top:12px"><h3>${t("map")}</h3><svg viewBox="0 0 400 220" style="width:100%;background:var(--ink);border-radius:8px">${dots}</svg></div>` : ""}
    <div class="card" style="margin-top:12px"><h3>${t("upcoming")}</h3>${upcoming.length ? `<table>${upcoming.map(u => `<tr><td>${esc(u.name || "")}</td><td>${esc(u.server)}</td><td>T${u.tier ?? "—"} Lv ${u.level ?? "—"}</td><td class="teal tabular">${t("eta")} ${eta(u.eta, data.now)}</td></tr>`).join("")}</table>` : `<div class="empty">${t("noData")}</div>`}</div>
    ${shown.map(sv => `<section style="margin-top:16px"><h3>${esc(sv.server)} · ${sv.count || 0} ${t("activeBosses")}</h3>
      <div class="grid-2">${(sv.bosses || []).map(b => `<article class="card pad">
        <b>${esc(b.name)}</b>
        <div class="muted">Tier ${b.tier ?? "—"} · Lv ${b.level ?? "—"}</div>
        <div class="row" style="margin-top:8px">
          <span class="chip teal tabular">${t("coords")} ${b.x} ${b.y}</span>
          <span class="chip">${t("activeFor")} ${elapsed(b.since, data.now)}</span>
          <button class="btn copy-xy" data-xy="${b.x} ${b.y}">${t("copyPos")}</button>
        </div>
      </article>`).join("") || `<div class="empty">${t("emptyBoss")}</div>`}</div>
    </section>`).join("")}`;
  $("#bserver").addEventListener("change", (e) => go("/bosses", { server: e.target.value || undefined }));
  root.querySelectorAll(".copy-xy").forEach(b => b.addEventListener("click", () => copy(b.dataset.xy)));
}

async function viewPvp(root, q) {
  const data = await getJson("players.php?pvp=1");
  let kills = data.kills || [];
  const servers = [...new Set(kills.map(k => k.server).filter(Boolean))];
  if (q.server) kills = kills.filter(k => k.server === q.server);
  if (q.favs) kills = kills.filter(k => isFavP(k.killer) || isFavP(k.victim));
  const map = new Map();
  for (const k of data.kills || []) {
    const a = map.get(k.killer) || { name: k.killer, k: 0, d: 0 }; a.k++; map.set(k.killer, a);
    const b = map.get(k.victim) || { name: k.victim, k: 0, d: 0 }; b.d++; map.set(k.victim, b);
  }
  const top = [...map.values()].sort((a, b) => b.k - a.k || a.d - b.d).slice(0, 12);
  root.innerHTML = `
    <div class="row">
      <select id="pserver"><option value="">${t("allServers")}</option>${servers.map(s => `<option ${q.server === s ? "selected" : ""}>${esc(s)}</option>`).join("")}</select>
      <label class="chip"><input type="checkbox" id="pfavs" ${q.favs ? "checked" : ""}> ${t("onlyFavs")}</label>
    </div>
    <div class="grid-2" style="margin-top:12px">
      <div class="card"><h3>${t("topKillers")}</h3><table>${top.map((r, i) => `<tr><td class="mist">${i + 1}</td><td>${playerLink(r.name)}</td><td class="ok">${r.k}</td><td class="danger">${r.d}</td></tr>`).join("")}</table></div>
      <div class="card"><h3>${t("feed")}</h3>${kills.length ? `<table>${kills.map(k => `<tr>
        <td class="ok">${playerLink(k.killer)}${isFavP(k.killer) ? " ★" : ""}</td>
        <td class="danger">${playerLink(k.victim)}${isFavP(k.victim) ? " ★" : ""}</td>
        <td class="mist">${esc(k.server || "")} ${timeAgo(k.time)}</td>
      </tr>`).join("")}</table>` : `<div class="empty">${t("emptyPvp")}</div>`}</div>
    </div>`;
  $("#pserver").addEventListener("change", (e) => go("/pvp", { server: e.target.value || undefined, favs: q.favs }));
  $("#pfavs").addEventListener("change", (e) => go("/pvp", { server: q.server, favs: e.target.checked ? "1" : undefined }));
}

async function viewItems(root, q) {
  await ensureItems();
  const cats = [...new Set(itemsList.map(i => i.eq?.cat).filter(Boolean))].sort();
  let list = itemsList;
  const n = (q.q || "").toLowerCase();
  if (n) list = list.filter(i => (i.itemName || i.id).toLowerCase().includes(n) || i.id.toLowerCase().includes(n));
  if (q.rarity) list = list.filter(i => String(i.rarity || 0) === q.rarity);
  if (q.cat) list = list.filter(i => i.eq?.cat === q.cat);
  if (q.kind === "weapon") list = list.filter(i => i.eq?.type === 1);
  if (q.kind === "armor") list = list.filter(i => i.eq?.type === 0);
  if (q.kind === "acc") list = list.filter(i => ["Necklace", "Ring", "Bag"].includes(i.eq?.cat));
  list = [...list].sort((a, b) => (a.itemName || a.id).localeCompare(b.itemName || b.id));
  const saved = itemsList.filter(i => prefs.favItems.includes(i.id));
  const limit = Number(q.n) || 80;
  root.innerHTML = `
    <form class="row" id="iform">
      <input name="q" value="${esc(q.q || "")}" placeholder="${t("item")}" style="flex:1">
      <select name="rarity"><option value="">${t("allRarities")}</option>${[0,1,2,3,4,5].map(r => `<option value="${r}" ${q.rarity === String(r) ? "selected" : ""}>${rarityName(r)}</option>`).join("")}</select>
      <select name="cat"><option value="">${t("allCats")}</option>${cats.map(c => `<option ${q.cat === c ? "selected" : ""}>${esc(c)}</option>`).join("")}</select>
      <select name="kind">
        <option value="">${t("allKinds")}</option>
        <option value="weapon" ${q.kind === "weapon" ? "selected" : ""}>${t("weapon")}</option>
        <option value="armor" ${q.kind === "armor" ? "selected" : ""}>${t("armor")}</option>
        <option value="acc" ${q.kind === "acc" ? "selected" : ""}>${t("accessory")}</option>
      </select>
      <button class="btn primary">${t("search")}</button>
      <span class="muted">${list.length}</span>
    </form>
    ${saved.length ? `<div style="margin:12px 0"><b>${t("favItems")}</b><div class="row" style="margin-top:6px">${saved.map(i => itemHot(i.id, itemImg(i.icon, i.itemName, "") + " " + esc(i.itemName), "chip")).join("")}</div></div>` : ""}
    <div class="card" style="margin-top:12px;overflow:auto"><table>
      <thead class="sticky-head"><tr><th></th><th>ID</th><th>${t("item")}</th><th>${t("category")}</th><th>${t("rarity")}</th></tr></thead>
      <tbody>${list.slice(0, limit).map(i => `<tr>
        <td>${itemHot(i.id, itemImg(i.icon, i.itemName))}</td>
        <td class="mist" style="font-family:ui-monospace">${esc(i.id)}</td>
        <td>${itemHot(i.id, `<b>${esc(i.itemName || i.id)}</b>`)}</td>
        <td class="mist">${esc(i.eq?.cat || "—")}</td>
        <td class="r${i.rarity || 0}">${rarityName(i.rarity)}</td>
      </tr>`).join("")}</tbody>
    </table></div>
    ${list.length > limit ? `<button class="btn" id="more" style="width:100%;margin-top:12px">${t("loadMore")} (${limit} ${t("ofTotal")} ${list.length})</button>` : ""}`;
  $("#iform").addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    go("/items", { q: fd.get("q") || undefined, rarity: fd.get("rarity") || undefined, cat: fd.get("cat") || undefined, kind: fd.get("kind") || undefined });
  });
  $("#more")?.addEventListener("click", () => go("/items", { ...q, n: String(limit + 80) }));
  bindItemHots(root);
}

async function viewCompare(root, q) {
  await ensureItems().catch(() => {});
  const load = async (name) => name ? getJson("players.php?name=" + encodeURIComponent(name)).catch(() => null) : null;
  const [a, b] = await Promise.all([load(q.a), load(q.b)]);
  const col = (p) => {
    if (!p?.name) return `<div class="card pad muted">${t("noData")}</div>`;
    const kills = p.kills || [];
    const wins = kills.filter(k => k.killer?.toLowerCase() === p.name.toLowerCase()).length;
    const filtered = filterClassEquip(p.equipment, p.class || "Warrior");
    return `<article class="card pad">
      <h2 style="font-family:var(--display);margin:0">${playerLink(p.name)}</h2>
      <ul style="list-style:none;padding:0">
        ${[["Level", p.level], ["Class", p.class], [t("gold"), fmtG(p.gold)], [t("honor"), fmtN(p.honor)], [t("guild"), p.guild || "—"], [t("kd"), wins + "/" + (kills.length - wins)], [t("score"), fmtN(equipScore(filtered))]].map(([k, v]) => `<li style="display:flex;justify-content:space-between;border-bottom:1px solid var(--line);padding:6px 0"><span class="mist">${k}</span><b>${esc(v)}</b></li>`).join("")}
        ${(p.classes || []).map(c => `<li style="display:flex;justify-content:space-between;padding:6px 0"><span class="mist">${esc(c.name)}</span><b>Lv ${c.level} · ${c.pct}%</b></li>`).join("")}
      </ul>
    </article>`;
  };
  const rows = [];
  if (a?.name && b?.name) {
    const stats = [
      ["Level", a.level || 0, b.level || 0],
      [t("gold"), a.gold || 0, b.gold || 0],
      [t("honor"), a.honor || 0, b.honor || 0],
    ];
    (a.classes || []).forEach(c => {
      const o = (b.classes || []).find(x => x.name === c.name);
      stats.push([c.name, c.level, o?.level || 0]);
    });
    rows.push(`<div class="card" style="margin-top:12px"><table>${stats.map(([k, av, bv]) => `<tr>
      <td class="${av > bv ? "ok" : av < bv ? "danger" : ""}">${fmtN(av)}</td>
      <td class="mist" style="text-align:center">${esc(k)}</td>
      <td class="${bv > av ? "ok" : bv < av ? "danger" : ""}" style="text-align:right">${fmtN(bv)}</td>
    </tr>`).join("")}</table></div>`);
  }
  root.innerHTML = `
    <form class="row" id="cform">
      <input name="a" value="${esc(q.a || "")}" placeholder="${t("compareA")}" style="flex:1">
      <input name="b" value="${esc(q.b || "")}" placeholder="${t("compareB")}" style="flex:1">
      <button class="btn primary">${t("compare")}</button>
    </form>
    ${!q.a && !q.b ? `<p class="muted">${t("emptyCompare")}</p>` : ""}
    <div class="grid-2" style="margin-top:12px">${col(a)}${col(b)}</div>
    ${rows.join("")}`;
  $("#cform").addEventListener("submit", (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    go("/compare", { a: fd.get("a") || undefined, b: fd.get("b") || undefined });
  });
}

function bindItemHots(root) {
  root.querySelectorAll(".item-hot").forEach(btn => {
    const id = btn.dataset.item;
    if (!id) return;
    btn.addEventListener("click", (e) => { e.preventDefault(); openItem(id); });
    btn.addEventListener("mouseenter", (e) => {
      if (!window.matchMedia("(hover: hover)").matches) return;
      clearTimeout(hoverTimer);
      hoverTimer = setTimeout(() => showTip(id, e.currentTarget.getBoundingClientRect()), 180);
    });
    btn.addEventListener("mouseleave", () => { clearTimeout(hoverTimer); hideTip(); });
  });
}

function tooltipText(rec) {
  if (!rec) return "";
  if (prefs.lang === "pt") return rec.tooltipPT || rec.tooltip || "";
  if (prefs.lang === "es") return rec.tooltipES || rec.tooltip || "";
  return rec.tooltip || "";
}

function showTip(id, rect) {
  hideTip();
  const rec = findItem(id);
  const tip = el(`<div class="tip" id="itemTip">
    <div class="row">${itemImg(rec?.icon, rec?.itemName || id, "lg")}<div>
      <b>${esc(rec?.itemName || id)}</b>
      <div class="r${rec?.rarity || 0}">${rarityName(rec?.rarity)} ${esc(rec?.eq?.cat || "")}</div>
    </div></div>
    ${tooltipText(rec) ? `<p class="muted" style="margin:8px 0 0">${esc(tooltipText(rec))}</p>` : ""}
  </div>`);
  document.body.appendChild(tip);
  const top = rect.top - tip.offsetHeight - 8;
  tip.style.left = Math.max(8, Math.min(window.innerWidth - 288, rect.left)) + "px";
  tip.style.top = (top < 8 ? rect.bottom + 8 : top) + "px";
}
function hideTip() { $("#itemTip")?.remove(); }

async function openItem(id) {
  hideTip();
  await ensureItems().catch(() => {});
  const rec = findItem(id);
  const market = await getJson("tienda.php").catch(() => ({ offers: [] }));
  const offers = (market.offers || []).filter(o => {
    const n = (o.item || "").toLowerCase();
    return n === (rec?.itemName || "").toLowerCase() || n === (rec?.id || "").toLowerCase() || n === String(id).toLowerCase();
  });
  const bg = el(`<div class="modal-bg" id="itemModal">
    <div class="modal">
      <button class="btn icon" id="closeM" style="position:absolute;right:8px;top:8px">✕</button>
      ${rec ? `
        <div class="row">
          ${itemImg(rec.icon, rec.itemName, "lg")}
          <div><h2 style="font-family:var(--display);margin:0">${esc(rec.itemName || rec.id)}</h2>
          <div class="r${rec.rarity || 0}">${rarityName(rec.rarity)}</div>
          <div class="mist" style="font-family:ui-monospace;font-size:12px">${esc(rec.id)}</div></div>
        </div>
        ${tooltipText(rec) ? `<p class="muted">${esc(tooltipText(rec))}</p>` : ""}
        ${rec.eq ? `<div class="grid-2" style="margin-top:8px">${Object.entries(rec.eq).map(([k, v]) => `<div class="chip"><div class="mist" style="font-size:10px">${esc(k)}</div><b>${esc(v)}</b></div>`).join("")}</div>` : ""}
        <div style="margin-top:12px"><button class="btn ${isFavI(rec.id) ? "primary" : ""}" id="saveI">${isFavI(rec.id) ? t("saved") : t("saveItem")}</button></div>
        <h3 style="font-size:12px;text-transform:uppercase;color:var(--mist)">${t("soldAt")}</h3>
        ${offers.length ? `<table>${offers.slice(0, 12).map(o => `<tr><td>${fmtN(o.amount)} · ${esc(o.player || "")} · ${esc(o.server || "")}</td><td class="gold">${fmtG(o.gold)}</td></tr>`).join("")}</table>` : `<p class="muted">${t("noOffers")}</p>`}
      ` : `<p>${esc(id)}</p>`}
    </div>
  </div>`);
  document.body.appendChild(bg);
  const close = () => bg.remove();
  bg.addEventListener("click", (e) => { if (e.target === bg) close(); });
  $("#closeM", bg).addEventListener("click", close);
  $("#saveI", bg)?.addEventListener("click", (e) => {
    toggleFavI(rec.id);
    e.currentTarget.textContent = isFavI(rec.id) ? t("saved") : t("saveItem");
    e.currentTarget.classList.toggle("primary", isFavI(rec.id));
  });
}

function openPalette() {
  if ($("#cmdk")) return;
  const pages = [
    ["/", t("home")], ["/players", t("players")], ["/guilds", t("guilds")],
    ["/market", t("market")], ["/bosses", t("bosses")], ["/pvp", t("pvp")],
    ["/items", t("items")], ["/compare", t("compare")],
  ];
  const box = el(`<div class="cmd" id="cmdk"><div class="cmd-box">
    <input id="cmdq" placeholder="${t("searchAll")}" autofocus>
    <div class="cmd-list" id="cmdlist"></div>
  </div></div>`);
  document.body.appendChild(box);
  const input = $("#cmdq", box);
  const list = $("#cmdlist", box);
  const close = () => box.remove();
  box.addEventListener("click", (e) => { if (e.target === box) close(); });
  function draw() {
    const q = input.value.toLowerCase().trim();
    const rows = [];
    pages.filter(p => !q || p[1].toLowerCase().includes(q)).forEach(p => rows.push({ type: "page", to: p[0], label: p[1] }));
    (prefs.favPlayers || []).filter(n => !q || n.toLowerCase().includes(q)).forEach(n => rows.push({ type: "player", name: n, label: n }));
    itemsList.filter(i => q && ((i.itemName || "").toLowerCase().includes(q) || i.id.toLowerCase().includes(q))).slice(0, 8).forEach(i => rows.push({ type: "item", id: i.id, label: i.itemName || i.id }));
    if (!rows.length) { list.innerHTML = `<div class="empty">${t("noResults")}</div>`; return; }
    list.innerHTML = rows.map((r, i) => `<div class="cmd-item ${i === 0 ? "active" : ""}" data-i="${i}">${esc(r.label)}</div>`).join("");
    list._rows = rows;
    list.querySelectorAll(".cmd-item").forEach(n => n.addEventListener("click", () => pick(rows[Number(n.dataset.i)])));
  }
  function pick(r) {
    close();
    if (r.type === "page") go(r.to);
    else if (r.type === "player") go("/players", { name: r.name });
    else if (r.type === "item") openItem(r.id);
  }
  input.addEventListener("input", draw);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape") close();
    if (e.key === "Enter") { const r = list._rows?.[0]; if (r) pick(r); }
  });
  draw();
  input.focus();
}

function boot() {
  applyChrome();
  $("#langSel").addEventListener("change", (e) => { prefs.lang = e.target.value; savePrefs(); applyChrome(); render(); });
  $("#compactChk").addEventListener("change", (e) => { prefs.compact = e.target.checked; savePrefs(); applyChrome(); });
  $("#contrastChk").addEventListener("change", (e) => { prefs.contrast = e.target.checked; savePrefs(); applyChrome(); });
  $("#bossBtn").addEventListener("click", async () => {
    if (!prefs.bossAlerts && "Notification" in window) {
      const p = await Notification.requestPermission();
      if (p !== "granted") return;
    }
    prefs.bossAlerts = !prefs.bossAlerts; savePrefs(); applyChrome();
  });
  $("#menuBtn").addEventListener("click", () => { $("#sidebar").classList.add("open"); $("#scrim").classList.remove("hidden"); });
  $("#scrim").addEventListener("click", () => { $("#sidebar").classList.remove("open"); $("#scrim").classList.add("hidden"); });
  $("#moreBtn")?.addEventListener("click", () => { $("#sidebar").classList.add("open"); $("#scrim").classList.remove("hidden"); });
  $("#searchBtn").addEventListener("click", openPalette);
  $("#refreshBtn").addEventListener("click", () => { cache.clear(); render(); });
  window.addEventListener("hashchange", () => { $("#sidebar").classList.remove("open"); $("#scrim").classList.add("hidden"); render(); });
  window.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); openPalette(); }
    if (e.key === "Escape") { hideTip(); $("#itemModal")?.remove(); $("#cmdk")?.remove(); }
  });
  ensureItems().catch(() => {});
  render();
}
document.addEventListener("DOMContentLoaded", boot);
